export const STORES = [];
