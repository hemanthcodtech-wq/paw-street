export const PRODUCTS = [];
